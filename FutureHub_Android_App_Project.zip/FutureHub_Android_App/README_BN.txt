# FutureHub Android App

এটি FutureHub ওয়েবসাইটের Android WebView অ্যাপ প্রজেক্ট।

## App details
- App name: FutureHub
- Website: https://futurehubbd.netlify.app/
- Package: com.futurehubbd.app
- Minimum Android: Android 6.0 (API 23)
- Supports JavaScript, Supabase web login/session cookies, and image/video file picker.

## APK তৈরি করার সহজ উপায় (GitHub Actions)
1. GitHub-এ একটি নতুন repository তৈরি করো।
2. এই ZIP Extract করে ভেতরের সব ফাইল repository-তে upload করো (root-এ `app`, `.github`, `build.gradle`, `settings.gradle` থাকবে)।
3. Repository-তে **Actions** tab খোলো।
4. **Build FutureHub APK** workflow নির্বাচন করে **Run workflow** চাপো।
5. Build শেষ হলে workflow run-এর নিচে **Artifacts** থেকে `FutureHub-Android-APK` ডাউনলোড করো।
6. ZIP Extract করলে `app-debug.apk` পাবে। Android ফোনে সেটি খুলে install করো।

## গুরুত্বপূর্ণ
- এই ZIP source project; এটি নিজে APK নয়।
- APK build করতে GitHub Actions অথবা Android Studio/Android SDK দরকার।
- অ্যাপটি ওয়েবসাইটের বর্তমান ফিচার দেখায়; ওয়েবসাইট বা Supabase-এর ত্রুটি অ্যাপ নিজে ঠিক করে না।
- Public release-এর আগে signed release APK/AAB তৈরি এবং privacy/security পরীক্ষা করা উচিত।
